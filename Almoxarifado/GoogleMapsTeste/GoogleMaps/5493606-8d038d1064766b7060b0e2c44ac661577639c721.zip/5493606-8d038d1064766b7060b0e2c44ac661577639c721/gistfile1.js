var map;
var areacontainer = new Array(0);
var points = new Array(0);
var areaMarkers = new Array(0);
var areaPath = new Array(0);
var areaPath2 = new Array(0);
var polygon = new Array(0);
var temp_areaPath;
var perm;
var toggle_showmarkers = true;
var lineWidth = 1;
var lineColor = '#ff0000';
var fillColor = '#00FF00';
var areaDiv = document.getElementById('area');
var areaDivkm = document.getElementById('areakm');
var areaDivacres = document.getElementById('areaacres');
var perDivm = document.getElementById('per_m');
var perDivkm = document.getElementById('per_km');
var radiansPerDegree = Math.PI / 180.0;
var degreesPerRadian = 180.0 / Math.PI;
var earthRadiusMeters = 6367460.0;
var metersPerDegree = 2.0 * Math.PI * earthRadiusMeters / 360.0;
var metersPerKm = 1000.0;
var meters2PerHectare = 10000.0;
var feetPerMeter = 3.2808399;
var feetPerMile = 5280.0;
var acresPerMile2 = 640;
var reticleImage = new google.maps.MarkerImage('images/markers/reticle.png', new google.maps.Size(63, 63), new google.maps.Point(0, 0), new google.maps.Point(32, 32));
var reticleShape = {
    coords: [32, 32, 32, 32],
	type: 'rect'
};

function Gload() {}
function GUnload() {}
google.maps.event.addDomL
istener(window, 'load', initialize);

function initialize() 
{
	var latlng = new google.maps.LatLng(0, 0);
	var myOptions = {
		zoom: 1,
		center: latlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		draggableCursor: 'crosshair',
		mapTypeControlOptions: {
			style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
		}
	};
    
	map = new google.maps.Map(document.getElementById('map_canvas'), myOptions);
	google.maps.event.addListener(map, 'click', mapclick);
	resetmeasurements();
	newpolygon();
	document.getElementById("showmarkers").checked = true;
	geocoder = new google.maps.Geocoder();
	reticleMarker = new google.maps.Marker({
		position: latlng,
		map: map,
		icon: reticleImage,
		shape: reticleShape,
		optimized: false,
		zIndex: 5
	});
	google.maps.event.addListener(map, 'bounds_changed', function () {
		reticleMarker.setPosition(map.getCenter())
	})
}

function mapclick(event) 
{
	areacontainer[areacontainer.length - 1].push(event.latLng);
	display()
}

function resetmeasurements() 
{
	areaDiv.innerHTML = '0 m&sup2;';
	areaDivkm.innerHTML = '0 km&sup2;';
	areaDivacres.innerHTML = '0 Acres';
	perDivm.innerHTML = '0 m';
	perDivkm.innerHTML = '0 km'
}

function display() 
{
	clearMap();
	resetmeasurements();
    
	for (var j = 0; j < areacontainer.length; ++j) 
    {
		perm = 0;
		if (toggle_showmarkers) {
			for (var i = 0; i < areacontainer[j].length; ++i) {
				var marker = placeMarker(areacontainer[j][i], i, j);
				areaMarkers.push(marker);
				marker.setMap(map)
			}
		}
		temp_areaPath = new google.maps.Polyline({
			path: areacontainer[j],
			strokeColor: lineColor,
			strokeOpacity: 1.0,
			strokeWeight: lineWidth,
			geodesic: true
		});
		temp_areaPath.setMap(map);
		areaPath.push(temp_areaPath);
		perm = 1000 * temp_areaPath.inKm();
		if (areacontainer[j].length > 2) {
			temp_polygon = new google.maps.Polygon({
				paths: areacontainer[j],
				strokeColor: lineColor,
				strokeOpacity: 1.0,
				strokeWeight: lineWidth,
				fillColor: fillColor,
				geodesic: true,
				fillOpacity: 0.5,
				clickable: false
			});
			temp_polygon.setMap(map);
			polygon.push(temp_polygon);
			areaMeters2 = PlanarPolygonAreaMeters2(areacontainer[j]);
			areaDiv.innerHTML = Areas(areaMeters2);
			areaDivkm.innerHTML = Areaskm(areaMeters2);
			areaDivacres.innerHTML = Areasacres(areaMeters2)
		}
		perDivm.innerHTML = perm.toFixed(3) + ' m';
		perDivkm.innerHTML = (perm / 1000).toFixed(3) + ' km'
	}
}

function clearMap()
{
	if (areaMarkers) {
		for (i in areaMarkers) {
			areaMarkers[i].setMap(null)
		}
	}
	if (areaPath.length > 0) {
		for (i in areaPath) {
			areaPath[i].setMap(null)
		}
	}
	if (areaPath2.length > 0) {
		for (i in areaPath2) {
			areaPath2[i].setMap(null)
		}
	}
	if (polygon.length > 0) {
		for (i in polygon) {
			polygon[i].setMap(null)
		}
	}
	areaMarkers = new Array(0);
	areaPath = new Array(0);
	areaPath2 = new Array(0);
	polygon = new Array(0)
}

function placeMarker(location, number, index) 
{
	var image = new google.maps.MarkerImage('http://www.freemaptools.com/images/gmmarkersv3/marker.png', new google.maps.Size(20, 34), new google.maps.Point(0, 0), new google.maps.Point(9, 33));
	var shadow = new google.maps.MarkerImage('http://www.freemaptools.com/images/gmmarkersv3/shadow.png', new google.maps.Size(28, 22), new google.maps.Point(0, 0), new google.maps.Point(1, 22));
	var marker = new google.maps.Marker({
		position: location,
		map: map,
		shadow: shadow,
		icon: image,
		draggable: true
	});
	var f = function (index, number) {
		return function () {
			areacontainer[index][number] = marker.position;
			display()
		}
	};
	google.maps.event.addListener(marker, 'dragend', f(index, number));
	return marker
}

function Areas(areaMeters2)
{
	var areaHectares = areaMeters2 / meters2PerHectare;
	var areaKm2 = areaMeters2 / metersPerKm / metersPerKm;
	var areaFeet2 = areaMeters2 * feetPerMeter * feetPerMeter;
	var areaMiles2 = areaFeet2 / feetPerMile / feetPerMile;
	var areaAcres = areaMiles2 * acresPerMile2;
	return areaMeters2.toFixed(3) + ' m&sup2; '
}

function Areaskm(areaMeters2)
{
	var areaHectares = areaMeters2 / meters2PerHectare;
	var areaKm2 = areaMeters2 / metersPerKm / metersPerKm;
	var areaFeet2 = areaMeters2 * feetPerMeter * feetPerMeter;
	var areaMiles2 = areaFeet2 / feetPerMile / feetPerMile;
	var areaAcres = areaMiles2 * acresPerMile2;
	return areaKm2.toFixed(3) + ' km&sup2; '
}

function Areasacres(areaMeters2)
{
	var areaHectares = areaMeters2 / meters2PerHectare;
	var areaKm2 = areaMeters2 / metersPerKm / metersPerKm;
	var areaFeet2 = areaMeters2 * feetPerMeter * feetPerMeter;
	var areaMiles2 = areaFeet2 / feetPerMile / feetPerMile;
	var areaAcres = areaMiles2 * acresPerMile2;
	return areaAcres.toFixed(3) + ' Acres '
}

function PlanarPolygonAreaMeters2(points) 
{
	var a = 0.0;
	for (var i = 0; i < points.length; ++i) 
    {
		var j = (i + 1) % points.length;
		var xi = points[i].lng() * metersPerDegree * Math.cos(points[i].lat() * radiansPerDegree);
		var yi = points[i].lat() * metersPerDegree;
		var xj = points[j].lng() * metersPerDegree * Math.cos(points[j].lat() * radiansPerDegree);
		var yj = points[j].lat() * metersPerDegree;
		a += xi * yj - xj * yi
	}
	return Math.abs(a / 2.0)
}

function AddPolylines(ps, lineColor, lineWidth)
{
	lines = [];
	var line = new GPolyline(ps, lineColor, lineWidth);
	lines.push(line);
	map.addOverlay(line);
    
	for (var i = 0; i < ps.length; ++i) 
    {
		polygonPoints.push(ps[i])
	}
	return line.getLength()
}

google.maps.Polyline.prototype.inKm = function (n) 
{
	var a = this.getPath(n),
	len = a.getLength(),
	dist = 0;
	for (var i = 0; i < len - 1; i++) 
    {
		dist += a.getAt(i).kmTo(a.getAt(i + 1))
	}
	return dist
};

google.maps.LatLng.prototype.kmTo = function (a) 
{
	var e = Math,
	ra = e.PI / 180;
	var b = this.lat() * ra,
	c = a.lat() * ra,
	d = b - c;
	var g = this.lng() * ra - a.lng() * ra;
	var f = 2 * e.asin(e.sqrt(e.pow(e.sin(d / 2), 2) + e.cos(b) * e.cos(c) * e.pow(e.sin(g / 2), 2)));
	return f * 6378.137
};

function clearallpoints() 
{
	areacontainer = new Array(0);
	points = new Array(0);
	areacontainer.push(points);
	display()
}

function DeleteLastPoint() 
{
	if (areacontainer[areacontainer.length - 1].length > 0) areacontainer[areacontainer.length - 1].length--;
	display()
}

function uploadfile(theform) 
{
	theform.submit();
	setStatus("<p>Uploading...</p><p><img src='images/loading.gif'/></p>", "msg")
}

function setStatus(theStatus, theObj) 
{
	obj = document.getElementById(theObj);
	if (obj) {
		obj.innerHTML = "<div class=\"bold\">" + theStatus + "</div>"
	}
}

function MapClickLater2(lat, lng) 
{
	var point = new google.maps.LatLng(lat, lng);
	areacontainer[areacontainer.length - 1].push(point)
}

function newpolygon()
{
	points = new Array(0);
	areacontainer.push(points)
}

function finishedloadingkml() {
	display();
	zoomtofit()
}

function zoomtofit() 
{
	var latlngbounds = new google.maps.LatLngBounds();
	for (var j = 0; j < areacontainer.length; ++j) 
    {
		for (var i = 0; i < areacontainer[j].length; ++i) 
        {
			latlngbounds.extend(areacontainer[j][i])
		}
	}
	map.setCenter(latlngbounds.getCenter());
	map.fitBounds(latlngbounds)
}

function toggleshowhidemarkers() 
{
	var showmarkers = document.getElementById("showmarkers").checked;
	if (showmarkers) {
		toggle_showmarkers = true;
		display()
	} else {
		toggle_showmarkers = false;
		display()
	}
}