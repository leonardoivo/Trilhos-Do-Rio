# buscaviacep
Classe para pesquisar o CEP atraves do servico gratuito viacep.<br>
Uso Simples, basta dar uma olhada no arquivo teste.php :D<br>
<br>
<b>Instalação Via composer:</b><br>
composer require jarouche/viacep
<br><br>
<b>Instalação sem composer:</b><br>
require __DIR__ . '/src/BuscaViaCEP_inc.php';