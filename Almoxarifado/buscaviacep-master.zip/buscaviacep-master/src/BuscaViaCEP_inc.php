<?php

require_once 'ViaCEPInterface.php';
require_once 'BuscaViaCEP.php';
require_once 'BuscaViaCEPQuerty.php';
require_once 'BuscaViaCEPXML.php';
require_once 'BuscaViaCEPJSON.php';
require_once 'BuscaViaCEPJSONP.php';
require_once 'BuscaViaCEPPiped.php';
require_once 'HelperViaCep.php';

