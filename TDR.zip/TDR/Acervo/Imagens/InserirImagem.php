<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt" lang="pt-BR">

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Cadastrar imagem ou foto</title>

</head>
<body>
	<div   style="text-align:center;">
<h1>  Imagens</h1>



<form method="post" action="CrudImagens.php?operacao=1"> 

Nome da imagem:<input type="text" name="nome_imagem"> <br/>
Autor: <input type="text" name="autor">
Data de publicação:<input type="date"  name="data_de_inclusao">
<input type="submit" name="cadastrar"><br/>

</form>
</div>


</body>
</html>
