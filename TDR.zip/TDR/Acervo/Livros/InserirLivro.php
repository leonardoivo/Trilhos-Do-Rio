<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt" lang="pt-BR">

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Ebook alterados das lojas  Kobo</title>

</head>
<body>
	<div   style="text-align:center;">
<h1>  Livros</h1>



<form method="post" action="CrudLivro.php?operacao=1"> 

Nome do livro:<input type="text" name="nomeDoLivro"> <br/>
Editor: <input type="text" name="editora">
Data de publicação:<input type="date"  name="dataDeCadastramento">
<input type="submit" name="cadastrar"><br/>

</form>
</div>


</body>
</html>
