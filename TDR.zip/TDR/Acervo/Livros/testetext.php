
<?php

echo $_POST['nome'];
?>
