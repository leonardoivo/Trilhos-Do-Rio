create table Rotas (id int auto_increment primary key, nome_rota varchar(20))
