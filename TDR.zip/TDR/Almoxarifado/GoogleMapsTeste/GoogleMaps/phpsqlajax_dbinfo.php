<?php
$username="root";
$password="";
$database="googlemaps";
?>
