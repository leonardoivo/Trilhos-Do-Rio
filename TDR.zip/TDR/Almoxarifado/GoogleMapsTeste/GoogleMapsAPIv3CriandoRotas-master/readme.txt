Google Maps API v3: Criando rotas

Um pequeno projeto utilizando o Google Maps JavaScript API v3 para criar rotas entre dois endere�os.

Demo: http://www.princiweb.com.br/demos/google-maps-api-v3-criando-rotas/