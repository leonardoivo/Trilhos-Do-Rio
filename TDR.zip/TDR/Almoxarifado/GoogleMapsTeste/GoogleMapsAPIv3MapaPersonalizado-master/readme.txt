Google Maps API v3: Mapa personalizado

Um pequeno projeto utilizando o Google Maps JavaScript API v3 e Google Maps Utility Library v3 para gerar um mapa com marcadores personalizados, caixa de informa��es estilizadas por CSS e agrupamento de marcadores pr�ximos.

Demo: http://www.princiweb.com.br/demos/google-maps-api-v3-criando-mapa-personalizado/

Google Maps JavaScript API v3: https://developers.google.com/maps/documentation/javascript/
Google Maps Utility Library v3: https://code.google.com/p/google-maps-utility-library-v3/