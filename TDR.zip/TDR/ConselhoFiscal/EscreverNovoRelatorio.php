<!DOCTYPE html>

<html>
<head>

<link href=".././Estilos/css/bootstrap.css" rel="stylesheet">
    <link href=".././Estilos/css/bootstrap-responsive.css" rel="stylesheet">
    <link href=".././Estilos/css/bootstrap-min.css" rel="stylesheet">
    <!--Javascript -->
     <script src=".././Estilos/js/bootstrap.js"></script>
      <script src=".././Estilos/js/bootstrap-min.js"></script>





</head>
<body>



<?php
include("../config.php");
session_start();
$usuario=$_SESSION["usuario"];

if(isset($usuario)){
?>
	<form name="registrar" method="post" action="CrudConselho.php?operacao=1" >
	Parecer: <input type="text" name="Parecer"><br/>
	Relatório: <textarea name="relatorio" rows="4" cols="50"></textarea>
	
	<input type="submit" text="enviar">
	</form>
	
	<a href="../ConselhoFiscal/conselhofiscal.php" onclick='location.replace("conselhofiscal.php")'>voltar</a>

	
<?	


}
	else{
		
		header("Location:login.html");
		
		}

?>
</body>
</html>
