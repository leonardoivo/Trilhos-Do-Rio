<?php

echo "Aqui não tem nada para você ver, seu enxerido!";
?>