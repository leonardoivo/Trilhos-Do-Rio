<?php 
include("../config.php");
session_start();
$usuario=$_SESSION["usuario"];

function InserirLogEvento($usuario){
    $queryLogEvento = "insert into LogEventos ()";




}






?>