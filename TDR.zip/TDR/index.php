
<!doctype>

<html>
<head>
	<!-- CSS-->
	<link href="Estilos/css/bootstrap.css" rel="stylesheet">
    <link href="Estilos/css/bootstrap-responsive.css" rel="stylesheet">
    <link href="Estilos/css/bootstrap-min.css" rel="stylesheet">
    <!--Javascript -->
     <script src="Estilos/js/bootstrap.js"></script>
      <script src="Estilos/js/bootstrap-min.js"></script>

</head>
<body>
<?php
include("config.php");
session_start();
$usuario=$_SESSION['usuario'];


$queryPermissao="select u.nome, tb.nome_tabela, tb.link from usuarios u inner join perfil p on u.id_perfil=p.id_perfil inner join tabelas_sistema tb on p.id_perfil=tb.id_perfil where u.cpf=".$usuario;
$query=mysqli_query($link,$queryPermissao);
$QueryNomeUsuario = "SELECT nome FROM usuarios	WHERE cpf =".$usuario;
$queryNome=mysqli_query($link,$QueryNomeUsuario);
$nome = "";
if(isset($usuario)){
 
while($linhaNome=mysqli_fetch_assoc($queryNome)){

$nome = $linhaNome['nome'];

}



	echo "Ola ".$nome."!</br>";
	echo "<h1> Pagina inicial</h1>";
	//echo date('l jS \of F Y h:i:s A');
	//echo date("l");
	
	echo "<nav>";





	while($linha=mysqli_fetch_assoc($query)){
   // $usuario_nome = linha['nome'];
		$paginas=$linha['nome_tabela'];
		$pasta= $linha['link']."/";
		
       // echo "<a href=\"#\">". $paginas."</a>   ";
		echo "<tr><td> <a href=\"".$pasta.$paginas.".php\">".$paginas. "</a>";



	}
//	echo $usuario_nome;
	echo "<a href=\"index.php?saida=1\" onclick='location.replace(\"login.html\")'> Sair</a>";

	echo "</nav>";
	
	
	echo "</body></html>";
	
	
	
	}
	else{
		
		header("Location:login.html");
		
		}
		if(isset($_REQUEST["saida"])){

			//session_unset();
			// session_destroy();
		//	if (headers_sent()) {
		  //  die("O redirecionamento falhou. Por favor, clique neste link: <a href=...>");
		  //   }
		  //  else{
			session_unset();
			session_destroy();
			header("Location: login.html");
			 //exit(header("Location: login.html"));
		   //}
	
	
		}
?>
</body>
</html>
