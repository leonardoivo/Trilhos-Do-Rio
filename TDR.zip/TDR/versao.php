<?php
phpinfo();

?>
